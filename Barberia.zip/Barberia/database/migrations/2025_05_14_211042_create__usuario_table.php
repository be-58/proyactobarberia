<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('usuarios', function (Blueprint $table) {
        $table->id('ID_Usuario'); // Esto crea un bigserial primary key
    
        $table->string('nombre');
        $table->string('correo')->unique();
        $table->string('telefono')->nullable();
        $table->string('contrasena');
        $table->string('rol');
        $table->date('rol_caducidad')->nullable();
        $table->date('fecha_creacion');
    
    // Solo definir Estado una vez así:
        $table->foreignId('Estado')->constrained('estados', 'IDEstado');
    
        $table->timestamps(); // Esto crea created_at y updated_at
       });
        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('usuarios');
    }
};
