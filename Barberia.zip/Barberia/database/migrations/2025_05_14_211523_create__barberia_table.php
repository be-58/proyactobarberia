<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('barberias', function (Blueprint $table) {
        $table->id('IDBarberia');
        $table->unsignedBigInteger('IDUsuario');
        $table->string('nombre');
        $table->string('direccion');
        $table->string('telefono');
        $table->string('logo')->nullable();
        $table->string('propietario');
        $table->string('ciudad');
        $table->date('fecha_creacion');
        $table->date('fecha_caducidad')->nullable();
        $table->unsignedBigInteger('Estado');
        $table->timestamps();

        $table->foreign('IDUsuario')->references('ID_Usuario')->on('usuarios');
        $table->foreign('Estado')->references('IDEstado')->on('estados');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('barberias');
    }
};