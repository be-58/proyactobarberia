<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('citas', function (Blueprint $table) {
    $table->id('IDCita'); // Cambiado de IDAgenda a IDCita (parece más apropiado)
    
    // Relación con usuarios
    $table->foreignId('IDUsuario')
          ->constrained('usuarios', 'ID_Usuario')
          ->onDelete('cascade');
    
    // Relación con barberías
    $table->foreignId('IDBarberia')
          ->constrained('barberias', 'IDBarberia')
          ->onDelete('cascade');
    
    // Relación con servicios
    $table->foreignId('IDServicio')
          ->constrained('servicios', 'IDServicio')
          ->onDelete('cascade');
    
    $table->dateTime('fecha');
    $table->time('hora');
    
    // Relación con estados
    $table->foreignId('estado') // Recomiendo minúsculas para consistencia
          ->constrained('estados', 'IDEstado')
          ->onDelete('restrict');
    
    $table->date('fecha_caducidad')->nullable();
    $table->date('fecha_creacion');
    $table->timestamps();
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('citas');
    }
};